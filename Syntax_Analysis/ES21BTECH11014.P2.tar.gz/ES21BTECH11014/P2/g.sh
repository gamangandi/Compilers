#!/bin/bash
lex lex_prog.l
bison -d -t -Wcounterexamples yacc_prog.y
gcc lex.yy.c yacc_prog.tab.c
./a.out input.txt